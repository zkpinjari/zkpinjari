# Capstone_Project-Crime_in_India

In this repository i'm analyzing crime data. 

There Are 4 phases include -:

phase1. Data collection/preparation

Phase2. State-wise analysis

Phase3. SQL operations

Phase4. Unsupervised ML (clustering). 