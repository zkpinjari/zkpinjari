## Website used to collect data are :

1) https://data.gov.in/resource/stateuts-wise-literacy-rates-census-2001-and-2011
2) https://www.census2011.co.in/sexratio.php
3) https://www.indiaonlinepages.com/population/literacy-rate-in-india.html
4) https://data.gov.in/search?title=crime
5) https://www.wbhealth.gov.in/other_files/2007/14_5.html

